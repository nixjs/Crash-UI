import { useState } from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";
import { Schema, Model, uint32, uint64, int16, string, uint8 } from "./buffer";

const commentSchema = new Schema({
  id: string,
  code: uint32,
  formattedCode: string,
  drawTime: uint32,
  configId: string,
  status: uint8,
  gameSymbol: uint8,
  luckyNumbersList: [uint8],
  xDMaxLuckyNumbersList: [uint8],
});
const post = new Model(commentSchema);

// Typescript knows `result` is of type {x: number, y: number}
const data = {
  id: "50002732 3591264               ",
  code: 12297,
  formattedCode: "#012297",
  drawTime: 1684837500,
  configId: "4898947120",
  status: 1,
  gameSymbol: 6,
  luckyNumbersList: [],
  xDMaxLuckyNumbersList: [],
};
const result = post.toBuffer(data);

console.log({
  root: data,
  result,
  from: post.fromBuffer(result),
});

// import {
//   BufferSchema,
//   Model,
//   uint64,
// } from "@geckos.io/typed-array-buffer-schema";
// import {
//   uint8,
//   int16,
//   uint16,
//   int64,
//   string8,
// } from "@geckos.io/typed-array-buffer-schema";

// const playerSchema = BufferSchema.schema("player", {
//   message: { type: string8, length: 2 ^ (64 - 1), removeSpace: true },
//   timestamp: uint64,
//   votes: int16,
// });

// const mainModel = new Model(playerSchema, 8);
// const buffer = mainModel.toBuffer({
//   message: "500027323591008",
//   timestamp: 1,
//   votes: 2,
// });

// console.log({ buffer, from: mainModel.fromBuffer(buffer) });

function App() {
  const [count, setCount] = useState(0);

  return (
    <>
      <div>
        <a href="https://vitejs.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>Vite + React</h1>
      <div className="card">
        <button onClick={() => setCount((count) => count + 1)}>
          count is {count}
        </button>
        <p>
          Edit <code>src/App.tsx</code> and save to test HMR
        </p>
      </div>
      <p className="read-the-docs">
        Click on the Vite and React logos to learn more
      </p>
    </>
  );
}

export default App;
